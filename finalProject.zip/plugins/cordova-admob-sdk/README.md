# Google AdMob SDK for Cordova

This plugin is intended to be a dependency of other plugins.

## Dependents

- [cordova-plugin-admob-free](https://www.npmjs.com/package/cordova-plugin-admob-free)

## Disclaimer

This is NOT an official Google product. It is just a community-driven project, repackaging SDKs for Cordova plugins.
